
import React, { useState, useEffect } from 'react';
import Layout from './components/Layout';
import LoginScreen from './components/LoginScreen';
import Dashboard from './components/Dashboard';
import PrisonAdministration from './components/PrisonAdministration';
import Investigations from './components/Investigations';
import InformationDept from './components/InformationDept';
import MainBranch from './components/MainBranch';
import WantedManager from './components/WantedManager';
import ReportsManager from './components/ReportsManager';
import StorageManager from './components/SyncManager'; // Updated Import
import UserManager from './components/UserManager';
import InmateProfileModal from './components/InmateProfileModal';
import ReleaseOrder from './components/ReleaseOrder';
import DeveloperConsole from './components/DeveloperConsole'; // Import
import ErrorBoundary from './components/ErrorBoundary'; // Import
import { ViewState } from './types';
import { useSecurity } from './context/SecurityContext';

const App: React.FC = () => {
  const { currentUser } = useSecurity();
  const [currentView, setCurrentView] = useState<ViewState>('DASHBOARD');
  const [subView, setSubView] = useState<string | undefined>(undefined);
  const [selectedInmateId, setSelectedInmateId] = useState<string | null>(null);

  useEffect(() => {
    const handlePopState = (event: PopStateEvent) => {
      if (event.state && event.state.view) {
        setCurrentView(event.state.view);
        setSubView(event.state.subView);
      } else {
        setCurrentView('DASHBOARD');
      }
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  if (!currentUser) {
    return <LoginScreen />;
  }

  const handleShowProfile = (inmateId: string) => {
    setSelectedInmateId(inmateId);
  };

  const handleNavigate = (view: ViewState, sub?: string) => {
    window.history.pushState({ view, subView: sub }, '', '');
    setCurrentView(view);
    setSubView(sub);
  };

  const renderView = () => {
    switch (currentView) {
      case 'DASHBOARD':
        return <Dashboard onNavigate={handleNavigate} onShowProfile={handleShowProfile} />;
      case 'PRISON_ADMIN':
        return <PrisonAdministration onShowProfile={handleShowProfile} initialTab={subView} />;
      case 'INVESTIGATIONS':
        return <Investigations onShowProfile={handleShowProfile} initialTab={subView} />;
      case 'INFO_DEPT':
        return <InformationDept initialTab={subView} />;
      case 'MAIN_BRANCH':
        return <MainBranch initialTab={subView} />;
      case 'WANTED_MANAGER':
        return <WantedManager />;
      case 'REPORTS_CENTER':
        return <ReportsManager onNavigate={handleNavigate} />;
      case 'STORAGE_CENTER':
        return <StorageManager />;
      case 'USER_MANAGER':
        return <UserManager />;
      case 'RELEASE_ORDER':
        return <ReleaseOrder />;
      case 'DEVELOPER_CONSOLE':
        return <DeveloperConsole />;
      default:
        return <Dashboard onNavigate={handleNavigate} onShowProfile={handleShowProfile} />;
    }
  };

  return (
    <ErrorBoundary>
      <Layout currentView={currentView} onNavigate={handleNavigate}>
        <div className="animate-fadeIn pb-10">
          {renderView()}
        </div>

        {selectedInmateId && (
          <InmateProfileModal 
            inmateId={selectedInmateId} 
            onClose={() => setSelectedInmateId(null)} 
          />
        )}
      </Layout>
    </ErrorBoundary>
  );
};

export default App;
