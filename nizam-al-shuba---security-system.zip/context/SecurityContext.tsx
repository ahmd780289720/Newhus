
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { 
  Inmate, InspectionRecord, Case, InmateStatus, Ward, InvestigationMinute, 
  WantedPerson, Movement, BehaviorReport, User, AuditLog, UserRole, Department, FavoriteItem 
} from '../types';

interface SecurityContextType {
  // Auth
  currentUser: User | null;
  users: User[];
  login: (name: string, password: string) => boolean;
  logout: () => void;
  addUser: (user: User) => void;
  updateUser: (user: User) => void;
  deleteUser: (userId: string) => void;

  // Data
  inmates: Inmate[];
  inspections: InspectionRecord[];
  wards: Ward[];
  cases: Case[];
  minutes: InvestigationMinute[];
  wantedPersons: WantedPerson[];
  movements: Movement[];
  reports: BehaviorReport[];
  auditLogs: AuditLog[];
  favorites: FavoriteItem[];
  
  // Actions
  addInmate: (inmate: Inmate) => void;
  updateInmate: (inmate: Inmate) => void;
  deleteInmate: (id: string) => void;
  
  addInspection: (inspection: InspectionRecord) => void;
  updateInmateStatus: (id: string, status: InmateStatus) => void;
  assignWard: (inmateId: string, wardId: string) => void;
  addWard: (ward: Ward) => void;
  
  // Investigation Actions
  addCase: (newCase: Case) => void;
  addMinute: (minute: InvestigationMinute) => void;
  
  addWantedPerson: (person: WantedPerson) => void;
  updateWantedPerson: (person: WantedPerson) => void;
  deleteWantedPerson: (id: string) => void;
  updateWantedStatus: (id: string, status: WantedPerson['status']) => void;
  
  addMovement: (movement: Movement) => void;
  updateMovement: (movement: Movement) => void;

  // Favorites
  addFavorite: (item: FavoriteItem) => void;
  removeFavorite: (id: string) => void;

  // System
  createBackup: () => void;
  parseBackupFile: (file: File) => Promise<any>; 
  restoreData: (data: any) => void; 
  resetSystem: () => void;
  requestPersistentStorage: () => Promise<boolean>;
  
  // Dev Console
  updateRawData: (key: string, data: any[]) => void;
}

const SecurityContext = createContext<SecurityContextType | undefined>(undefined);

const DEFAULT_ADMIN_USER: User = {
  id: 'admin',
  name: 'admin',
  role: UserRole.ADMIN,
  department: Department.GENERAL_ADMIN,
  avatar: 'https://ui-avatars.com/api/?name=Admin&background=0D8ABC&color=fff',
  password: '123'
};

const loadFromStorage = (key: string, defaultValue: any) => {
  try {
    const saved = localStorage.getItem(key);
    if (saved === null) return defaultValue;
    const parsed = JSON.parse(saved);
    // Safety check: ensure arrays stay arrays
    if (Array.isArray(defaultValue) && !Array.isArray(parsed)) {
      return defaultValue;
    }
    return parsed;
  } catch (e) {
    console.error(`Error loading ${key}`, e);
    return defaultValue;
  }
};

const saveToStorage = (key: string, data: any) => {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (e: any) {
    console.error('Storage Save Error', e);
    alert('تحذير: مساحة التخزين ممتلئة، قد لا يتم حفظ البيانات الجديدة!');
  }
};

const toBase64 = (str: string) => window.btoa(unescape(encodeURIComponent(str)));
const fromBase64 = (str: string) => decodeURIComponent(escape(window.atob(str)));

export const SecurityProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  
  const [users, setUsers] = useState<User[]>(() => loadFromStorage('sec_sys_users_list', [DEFAULT_ADMIN_USER]));
  const [currentUser, setCurrentUser] = useState<User | null>(() => loadFromStorage('sec_sys_user', null));
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(() => loadFromStorage('sec_sys_logs', []));

  const [inmates, setInmates] = useState<Inmate[]>(() => loadFromStorage('sec_sys_inmates', []));
  const [inspections, setInspections] = useState<InspectionRecord[]>(() => loadFromStorage('sec_sys_inspections', []));
  const [wards, setWards] = useState<Ward[]>(() => loadFromStorage('sec_sys_wards', []));
  const [cases, setCases] = useState<Case[]>(() => loadFromStorage('sec_sys_cases', []));
  const [minutes, setMinutes] = useState<InvestigationMinute[]>(() => loadFromStorage('sec_sys_minutes', []));
  const [wantedPersons, setWantedPersons] = useState<WantedPerson[]>(() => loadFromStorage('sec_sys_wanted', []));
  const [movements, setMovements] = useState<Movement[]>(() => loadFromStorage('sec_sys_movements', []));
  const [reports, setReports] = useState<BehaviorReport[]>(() => loadFromStorage('sec_sys_reports', []));
  
  const [favorites, setFavorites] = useState<FavoriteItem[]>(() => loadFromStorage('sec_sys_favorites', []));

  // --- PERSISTENCE EFFECT HOOKS (Backup) ---
  // While we use synchronous saving in functions, these hooks act as a safety net
  useEffect(() => { saveToStorage('sec_sys_inmates', inmates); }, [inmates]);
  useEffect(() => { saveToStorage('sec_sys_inspections', inspections); }, [inspections]);
  useEffect(() => { saveToStorage('sec_sys_wards', wards); }, [wards]);
  useEffect(() => { saveToStorage('sec_sys_cases', cases); }, [cases]);
  useEffect(() => { saveToStorage('sec_sys_minutes', minutes); }, [minutes]);
  useEffect(() => { saveToStorage('sec_sys_wanted', wantedPersons); }, [wantedPersons]);
  useEffect(() => { saveToStorage('sec_sys_movements', movements); }, [movements]);
  useEffect(() => { saveToStorage('sec_sys_reports', reports); }, [reports]);
  useEffect(() => { saveToStorage('sec_sys_users_list', users); }, [users]);
  useEffect(() => { saveToStorage('sec_sys_logs', auditLogs); }, [auditLogs]);
  useEffect(() => { saveToStorage('sec_sys_favorites', favorites); }, [favorites]);
  
  useEffect(() => { 
    if(currentUser) localStorage.setItem('sec_sys_user', JSON.stringify(currentUser));
    else localStorage.removeItem('sec_sys_user');
  }, [currentUser]);

  const requestPersistentStorage = async (): Promise<boolean> => {
    if (navigator.storage && navigator.storage.persist) {
      return await navigator.storage.persist();
    }
    return false;
  };

  const logAction = (action: AuditLog['action'], target: string) => {
    if (!currentUser) return;
    const newLog: AuditLog = {
      id: Date.now().toString(),
      userId: currentUser.id,
      userName: currentUser.name,
      action,
      target,
      timestamp: new Date().toISOString()
    };
    setAuditLogs(prev => {
      const updated = [newLog, ...prev];
      saveToStorage('sec_sys_logs', updated);
      return updated;
    });
  };

  const login = (name: string, password: string): boolean => {
    const user = users.find(u => u.name === name && u.password === password);
    if (user) {
      setCurrentUser(user);
      logAction('LOGIN', 'تم تسجيل الدخول للنظام');
      return true;
    }
    return false;
  };

  const logout = () => {
    logAction('LOGOUT', 'تم تسجيل الخروج');
    setCurrentUser(null);
  };

  // --- ATOMIC SAVE FUNCTIONS (CRITICAL FIX) ---
  // These functions update state AND localStorage simultaneously to prevent data loss

  const addUser = (user: User) => {
    setUsers(prev => {
      const updated = [...prev, user];
      saveToStorage('sec_sys_users_list', updated);
      return updated;
    });
    logAction('CREATE', `إضافة مستخدم جديد: ${user.name}`);
  };

  const updateUser = (updatedUser: User) => {
    setUsers(prev => {
      const updated = prev.map(u => u.id === updatedUser.id ? updatedUser : u);
      saveToStorage('sec_sys_users_list', updated);
      return updated;
    });
    logAction('UPDATE', `تحديث بيانات المستخدم: ${updatedUser.name}`);
  };

  const deleteUser = (userId: string) => {
    setUsers(prev => {
      const updated = prev.filter(u => u.id !== userId);
      saveToStorage('sec_sys_users_list', updated);
      return updated;
    });
    logAction('DELETE', `حذف مستخدم ID: ${userId}`);
  };

  // Inmate Actions
  const addInmate = (inmate: Inmate) => {
    setInmates(prev => {
      const updated = [inmate, ...prev];
      saveToStorage('sec_sys_inmates', updated); // Immediate Save
      return updated;
    });
    logAction('CREATE', `تسجيل نزيل: ${inmate.fullName}`);
  };

  const updateInmate = (inmate: Inmate) => {
    setInmates(prev => {
      const updated = prev.map(i => i.id === inmate.id ? inmate : i);
      saveToStorage('sec_sys_inmates', updated);
      return updated;
    });
    logAction('UPDATE', `تحديث بيانات نزيل: ${inmate.fullName}`);
  };

  const deleteInmate = (id: string) => {
    setInmates(prev => {
      const updated = prev.filter(i => i.id !== id);
      saveToStorage('sec_sys_inmates', updated);
      return updated;
    });
    logAction('DELETE', `حذف نزيل ID: ${id}`);
  };

  // Other Actions
  const addInspection = (inspection: InspectionRecord) => {
    setInspections(prev => {
      const updated = [...prev, inspection];
      saveToStorage('sec_sys_inspections', updated);
      return updated;
    });
    updateInmateStatus(inspection.inmateId, InmateStatus.READY_FOR_HOUSING);
    logAction('UPDATE', `إتمام فحص أمني للنزيل ID: ${inspection.inmateId}`);
  };

  const updateInmateStatus = (id: string, status: InmateStatus) => {
    setInmates(prev => {
      const updated = prev.map(i => i.id === id ? { ...i, status } : i);
      saveToStorage('sec_sys_inmates', updated);
      return updated;
    });
  };

  const assignWard = (inmateId: string, wardId: string) => {
    setInmates(prev => {
      const updated = prev.map(i => i.id === inmateId ? { ...i, wardId, status: InmateStatus.DETAINED } : i);
      saveToStorage('sec_sys_inmates', updated);
      return updated;
    });
    setWards(prev => {
      const updated = prev.map(w => w.id === wardId ? { ...w, currentCount: w.currentCount + 1 } : w);
      saveToStorage('sec_sys_wards', updated);
      return updated;
    });
    logAction('UPDATE', `تسكين النزيل ID ${inmateId} في عنبر ${wardId}`);
  };

  const addWard = (ward: Ward) => {
    setWards(prev => {
      const updated = [...prev, ward];
      saveToStorage('sec_sys_wards', updated);
      return updated;
    });
    logAction('CREATE', `إضافة عنبر جديد: ${ward.name}`);
  };

  // --- CRITICAL FIX FOR INVESTIGATIONS ---
  const addCase = (newCase: Case) => {
    setCases(prev => {
      const updated = [newCase, ...prev];
      saveToStorage('sec_sys_cases', updated); // FORCE SAVE
      return updated;
    });
    logAction('CREATE', `فتح قضية جديدة: ${newCase.caseTitle}`);
  };

  const addMinute = (minute: InvestigationMinute) => {
    setMinutes(prev => {
      const updated = [minute, ...prev];
      saveToStorage('sec_sys_minutes', updated); // FORCE SAVE
      return updated;
    });
    logAction('CREATE', `إضافة محضر تحقيق للقضية ${minute.caseId}`);
  };
  
  const addWantedPerson = (person: WantedPerson) => {
    setWantedPersons(prev => {
      const updated = [person, ...prev];
      saveToStorage('sec_sys_wanted', updated);
      return updated;
    });
    logAction('CREATE', `إضافة مطلوب أمني: ${person.fullName}`);
  };

  const updateWantedPerson = (person: WantedPerson) => {
    setWantedPersons(prev => {
      const updated = prev.map(p => p.id === person.id ? person : p);
      saveToStorage('sec_sys_wanted', updated);
      return updated;
    });
    logAction('UPDATE', `تحديث بيانات مطلوب: ${person.fullName}`);
  };

  const deleteWantedPerson = (id: string) => {
     setWantedPersons(prev => {
       const updated = prev.filter(p => p.id !== id);
       saveToStorage('sec_sys_wanted', updated);
       return updated;
     });
     logAction('DELETE', `حذف مطلوب أمني ID: ${id}`);
  };

  const updateWantedStatus = (id: string, status: WantedPerson['status']) => {
    setWantedPersons(prev => {
      const updated = prev.map(p => p.id === id ? { ...p, status } : p);
      saveToStorage('sec_sys_wanted', updated);
      return updated;
    });
    logAction('UPDATE', `تحديث حالة مطلوب ID: ${id}`);
  };

  const addMovement = (movement: Movement) => {
    setMovements(prev => {
      const updated = [movement, ...prev];
      saveToStorage('sec_sys_movements', updated);
      return updated;
    });
    logAction('CREATE', `تسجيل حركة خروج للنزيل ID: ${movement.inmateId}`);
  };

  const updateMovement = (movement: Movement) => {
    setMovements(prev => {
      const updated = prev.map(m => m.id === movement.id ? movement : m);
      saveToStorage('sec_sys_movements', updated);
      return updated;
    });
    logAction('UPDATE', `تحديث حركة ID: ${movement.id}`);
  };

  const addFavorite = (item: FavoriteItem) => {
    setFavorites(prev => {
      if (!prev.some(f => f.id === item.id)) {
        const updated = [...prev, item];
        saveToStorage('sec_sys_favorites', updated);
        return updated;
      }
      return prev;
    });
  };

  const removeFavorite = (id: string) => {
    setFavorites(prev => {
      const updated = prev.filter(f => f.id !== id);
      saveToStorage('sec_sys_favorites', updated);
      return updated;
    });
  };

  const createBackup = () => {
    const data = {
      timestamp: new Date().toISOString(),
      version: '2.1',
      system: 'AL_HARES_SEC_SYSTEM',
      inmates, inspections, wards, cases, minutes, wantedPersons, movements, reports, users, auditLogs, favorites
    };
    
    const jsonString = JSON.stringify(data);
    const encryptedData = toBase64(jsonString);
    const blob = new Blob([encryptedData], { type: 'application/octet-stream' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `AlHares_Backup_${new Date().toISOString().split('T')[0].replace(/-/g,'')}.guard`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    logAction('CREATE', 'تصدير نسخة احتياطية مشفرة للنظام');
  };

  const parseBackupFile = async (file: File): Promise<any> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const content = e.target?.result as string;
          let jsonString;
          try {
             jsonString = fromBase64(content);
          } catch(err) {
             jsonString = content;
          }

          const data = JSON.parse(jsonString);
          if (!data.timestamp || !data.inmates) {
            reject('ملف غير صالح: بنية البيانات غير صحيحة.');
            return;
          }
          resolve(data);
        } catch (err) {
          reject('فشل قراءة الملف. الملف قد يكون تالفاً أو غير مدعوم.');
        }
      };
      reader.onerror = () => reject('حدث خطأ أثناء قراءة الملف.');
      reader.readAsText(file);
    });
  };

  const restoreData = (data: any) => {
    try {
      if(Array.isArray(data.inmates)) { setInmates(data.inmates); saveToStorage('sec_sys_inmates', data.inmates); }
      if(Array.isArray(data.inspections)) { setInspections(data.inspections); saveToStorage('sec_sys_inspections', data.inspections); }
      if(Array.isArray(data.wards)) { setWards(data.wards); saveToStorage('sec_sys_wards', data.wards); }
      if(Array.isArray(data.cases)) { setCases(data.cases); saveToStorage('sec_sys_cases', data.cases); }
      if(Array.isArray(data.minutes)) { setMinutes(data.minutes); saveToStorage('sec_sys_minutes', data.minutes); }
      if(Array.isArray(data.wantedPersons)) { setWantedPersons(data.wantedPersons); saveToStorage('sec_sys_wanted', data.wantedPersons); }
      if(Array.isArray(data.movements)) { setMovements(data.movements); saveToStorage('sec_sys_movements', data.movements); }
      if(Array.isArray(data.reports)) { setReports(data.reports); saveToStorage('sec_sys_reports', data.reports); }
      if(Array.isArray(data.users)) { setUsers(data.users); saveToStorage('sec_sys_users_list', data.users); }
      if(Array.isArray(data.auditLogs)) { setAuditLogs(data.auditLogs); saveToStorage('sec_sys_logs', data.auditLogs); }
      if(Array.isArray(data.favorites)) { setFavorites(data.favorites); saveToStorage('sec_sys_favorites', data.favorites); }
      
      logAction('UPDATE', 'استعادة النظام من نسخة احتياطية');
    } catch (e) {
      console.error("Restore failed", e);
      alert("حدث خطأ أثناء تطبيق البيانات.");
    }
  };

  const resetSystem = () => {
    localStorage.clear();
    const defaultUserList = [DEFAULT_ADMIN_USER];
    localStorage.setItem('sec_sys_users_list', JSON.stringify(defaultUserList));
    window.location.reload();
  };

  const updateRawData = (key: string, data: any[]) => {
    if (!Array.isArray(data)) return;

    switch(key) {
      case 'inmates': setInmates(data); saveToStorage('sec_sys_inmates', data); break;
      case 'cases': setCases(data); saveToStorage('sec_sys_cases', data); break;
      case 'minutes': setMinutes(data); saveToStorage('sec_sys_minutes', data); break;
      case 'wards': setWards(data); saveToStorage('sec_sys_wards', data); break;
      case 'inspections': setInspections(data); saveToStorage('sec_sys_inspections', data); break;
      case 'users': setUsers(data); saveToStorage('sec_sys_users_list', data); break;
      case 'wantedPersons': setWantedPersons(data); saveToStorage('sec_sys_wanted', data); break;
      case 'movements': setMovements(data); saveToStorage('sec_sys_movements', data); break;
      case 'reports': setReports(data); saveToStorage('sec_sys_reports', data); break;
    }
  };

  return (
    <SecurityContext.Provider value={{
      currentUser, users, login, logout, addUser, updateUser, deleteUser,
      inmates, inspections, wards, cases, minutes, wantedPersons, movements, reports, auditLogs, favorites,
      addInmate, updateInmate, deleteInmate,
      addInspection, updateInmateStatus, assignWard, addWard, addCase, addMinute,
      addWantedPerson, updateWantedPerson, deleteWantedPerson, updateWantedStatus,
      addMovement, updateMovement,
      addFavorite, removeFavorite,
      createBackup, parseBackupFile, restoreData, resetSystem,
      updateRawData, requestPersistentStorage
    }}>
      {children}
    </SecurityContext.Provider>
  );
};

export const useSecurity = () => {
  const context = useContext(SecurityContext);
  if (context === undefined) {
    throw new Error('useSecurity must be used within a SecurityProvider');
  }
  return context;
};
